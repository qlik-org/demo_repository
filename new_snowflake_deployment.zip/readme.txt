Original project name: new_snowflake
Exported on: 09/15/2026 12:50:43
Exported by: QTSEL\ehf
