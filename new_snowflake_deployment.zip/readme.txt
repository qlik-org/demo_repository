Original project name: new_snowflake
Exported on: 09/15/2026 12:55:37
Exported by: QTSEL\ehf
